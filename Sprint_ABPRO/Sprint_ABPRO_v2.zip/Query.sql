-- 1
CREATE TABLE `cliente` (
  `rutcliente` int NOT NULL,
  `clinombres` varchar(30) NOT NULL,
  `cliapellidos` varchar(50) NOT NULL,
  `clitelefono` varchar(20) NOT NULL,
  `cliafp` varchar(30) DEFAULT NULL,
  `clisistemasalud` int DEFAULT NULL,
  `clidireccion` varchar(100) NOT NULL,
  `clicomuna` varchar(50) NOT NULL,
  `cliedad` int NOT NULL,
  PRIMARY KEY (`rutcliente`)
);

CREATE TABLE `profesional` (
  `rut` int NOT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `apellido` varchar(50) DEFAULT NULL,
  `telefono` int DEFAULT NULL,
  `titulo` varchar(100) DEFAULT NULL,
  `proyecto` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`rut`)
);

CREATE TABLE `usuario` (
  `idusuario` int NOT NULL AUTO_INCREMENT,
  `rutcliente` int DEFAULT NULL,
  `rutprofecional` int DEFAULT NULL,
  `usuario` varchar(50) DEFAULT NULL,
  `clave` varchar(255) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  PRIMARY KEY (`idusuario`),
  UNIQUE KEY `rut_UNIQUE` (`rutcliente`),
  UNIQUE KEY `rutprofecional_UNIQUE` (`rutprofecional`),
  CONSTRAINT `usuario_cliente_fk` FOREIGN KEY (`rutcliente`) REFERENCES `cliente` (`rutcliente`),
  CONSTRAINT `usuario_profecional_fk` FOREIGN KEY (`rutprofecional`) REFERENCES `profesional` (`rut`)
);

CREATE TABLE `accidente` (
  `idaccidente` int NOT NULL AUTO_INCREMENT,
  `accfecha` date NOT NULL,
  `acchora` time NOT NULL,
  `acclugar` varchar(150) NOT NULL,
  `accorigen` varchar(100) NOT NULL,
  `accconsecuencias` varchar(100) DEFAULT NULL,
  `rutcliente` int NOT NULL,
  PRIMARY KEY (`idaccidente`),
  KEY `accidente_cliente_fk_idx` (`rutcliente`),
  CONSTRAINT `accidente_cliente_fk` FOREIGN KEY (`rutcliente`) REFERENCES `cliente` (`rutcliente`)
);

CREATE TABLE `visita` (
  `idvisita` int NOT NULL AUTO_INCREMENT,
  `visfecha` date NOT NULL,
  `vishora` time DEFAULT NULL,
  `vislugar` varchar(50) NOT NULL,
  `viscomentario` varchar(250) NOT NULL,
  `rutcliente` int NOT NULL,
  PRIMARY KEY (`idvisita`),
  KEY `visita_cliente_pk_idx` (`rutcliente`),
  CONSTRAINT `visita_cliente_pk` FOREIGN KEY (`rutcliente`) REFERENCES `cliente` (`rutcliente`)
);

CREATE TABLE `mae_chequeo` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
);

CREATE TABLE `chequeo_visita` (
  `idchequeo` int NOT NULL,
  `idvisita` int NOT NULL,
  `cumplimiento` bit(1) DEFAULT NULL,
  `obs` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`idchequeo`,`idvisita`),
  KEY `cv_visita_fk_idx` (`idvisita`),
  CONSTRAINT `cv_check_fk` FOREIGN KEY (`idchequeo`) REFERENCES `mae_chequeo` (`id`),
  CONSTRAINT `cv_visita_fk` FOREIGN KEY (`idvisita`) REFERENCES `visita` (`idvisita`)
);

CREATE TABLE `pago` (
  `idpago` int NOT NULL AUTO_INCREMENT,
  `fechapago` date DEFAULT NULL,
  `montopago` int DEFAULT NULL,
  `mes` int DEFAULT NULL,
  `año` int DEFAULT NULL,
  `rutcliente` int DEFAULT NULL,
  PRIMARY KEY (`idpago`),
  KEY `pago_cliente_fk_idx` (`rutcliente`),
  CONSTRAINT `pago_cliente_fk` FOREIGN KEY (`rutcliente`) REFERENCES `cliente` (`rutcliente`)
);

CREATE TABLE `capacitacion` (
  `idcapacitacion` int NOT NULL AUTO_INCREMENT,
  `capfecha` date NOT NULL,
  `caphora` time DEFAULT NULL,
  `caplugar` varchar(100) NOT NULL,
  `capduracion` int DEFAULT NULL,
  `rutcliente` int NOT NULL,
  PRIMARY KEY (`idcapacitacion`),
  KEY `cap_cliente_pk_idx` (`rutcliente`),
  CONSTRAINT `cap_cliente_pk` FOREIGN KEY (`rutcliente`) REFERENCES `cliente` (`rutcliente`)
);

CREATE TABLE `asistentes` (
  `idasistente` int NOT NULL AUTO_INCREMENT,
  `asisnombrecompleto` varchar(100) NOT NULL,
  `asisedad` int NOT NULL,
  `asiscorreo` varchar(70) DEFAULT NULL,
  `asistelefono` varchar(20) DEFAULT NULL,
  `idcapacitacion` int NOT NULL,
  PRIMARY KEY (`idasistente`),
  KEY `asis_capacit_fk_idx` (`idcapacitacion`),
  CONSTRAINT `asis_capacit_fk` FOREIGN KEY (`idcapacitacion`) REFERENCES `capacitacion` (`idcapacitacion`)
);

CREATE TABLE `administrativos` (
  `rut` int NOT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `apellido` varchar(50) DEFAULT NULL,
  `correo` varchar(100) DEFAULT NULL,
  `area` varchar(100) DEFAULT NULL,
  `idusuario` int DEFAULT NULL,
  PRIMARY KEY (`rut`),
  KEY `admin_usuario_fk_idx` (`idusuario`),
  CONSTRAINT `admin_usuario` FOREIGN KEY (`idusuario`) REFERENCES `usuario` (`idusuario`)
);

CREATE TABLE `asesorias` (
  `idasesoria` int NOT NULL AUTO_INCREMENT,
  `fecharealizacion` date DEFAULT NULL,
  `motivo` varchar(255) DEFAULT NULL,
  `rutprofecional` int DEFAULT NULL,
  PRIMARY KEY (`idasesoria`),
  KEY `asesoria_profecional_fk_idx` (`rutprofecional`),
  CONSTRAINT `asesoria_profecional_fk` FOREIGN KEY (`rutprofecional`) REFERENCES `profesional` (`rut`)
);

CREATE TABLE `actividades` (
  `idactividades` int NOT NULL AUTO_INCREMENT,
  `titulomejora` varchar(255) DEFAULT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  `plazoendias` int DEFAULT NULL,
  `idasesoria` int DEFAULT NULL,
  PRIMARY KEY (`idactividades`),
  KEY `activ_asesor_fk_idx` (`idasesoria`),
  CONSTRAINT `activ_asesor_fk` FOREIGN KEY (`idasesoria`) REFERENCES `asesorias` (`idasesoria`)
);

-- 2 

INSERT INTO cliente
	(rutcliente, clinombres, cliapellidos, clitelefono, cliafp, clisistemasalud, clidireccion, clicomuna, cliedad)
VALUES 
	(123456789, "Isaac", "Netero", 123, "Mas Vida", 1, "Japon", "Tokio", 150),
    (234567891, "Naruto", "Uzumaki", 234, "Menos Vida", 2, "Japon", "Valparaiso", 26),
    (345678912, "Gon", "Freecss", 345, "Otra Vida", 1, "Japon", "Valparaiso", 12);
    
INSERT INTO accidente 
	(accfecha, acchora, acclugar, accorigen, accconsecuencias, rutcliente)
VALUES
	("2023-01-01", "12:58:00", "Valpo", "Heridas de puñaladas", "Perdida de nen", 123456789),
    ("2022-05-13", "18:02:00", "Viña", "Pelea con Pain", "Empalamiento", 234567891),
    ("2022-08-08", "18:02:00", "Quilpue", "Lucha conta hormiga Quimera", "Estres postraumatico con desgaste corporal excesivo", 345678912);

INSERT INTO visita
	(visfecha, vishora, vislugar, viscomentario, rutcliente)
VALUES
	("2023-01-01", "12:58:00", "chillan", "Muy lindo todo", 123456789),
    ("2022-05-13", "18:02:00", "puchuncavi", "Muy feo todo", 234567891),
    ("2022-08-08", "18:02:00", "santiasco", "Muy reguleque todo", 345678912);

INSERT INTO mae_chequeo (nombre) VALUES ("Chequeo 1"), ("Chequeo 2"), ("Chequeo 3");

INSERT INTO chequeo_visita 
	(idchequeo, idvisita, cumplimiento, obs)
VALUES
	(1, 1, true, "Bien cumplido"),
   	(2, 2, false, ""),
	(3, 3, true, "Bien cumplido");
    
INSERT INTO pago
	(fechapago, montopago, mes, año, rutcliente)
VALUES
	("2023-01-01", 100000, 1 , 2023, 123456789),
    ("2022-05-13", 200000, 5 , 2022, 234567891),
    ("2020-08-08", 300000, 8 , 2020, 345678912);

INSERT INTO capacitacion
	(capfecha, caphora, caplugar, capduracion, rutcliente)
VALUES
	("2023-01-01", "12:50:00", "Valpo" , 3, 123456789),
    ("2022-05-13", "16:36:00", "Valpo" , 4, 234567891),
    ("2020-08-08", "08:12:00", "Viña" , 2, 345678912);

INSERT INTO asistentes
	(asisnombrecompleto, asisedad, asiscorreo, asistelefono, idcapacitacion)
VALUES
	("Francisco Gore", 99, "aaa@bbb.cl", 123456789, 1),
    ("Fernando Perez", 50, "ccc@ddd.cl", 789456123, 2),
	("Bryan Hell", 67, "eee@fff.cl", 987654321, 3);

INSERT INTO profesional 
	(rut, nombre, apellido, telefono, titulo, proyecto)
VALUES
	(987654321, "Netero", "", 12456, "Terrible Pro", "Proyecto 1"),
	(876543219, "Naruto", "", 12456, "Terrible Pro", "Proyecto 1"),
	(765432198, "Gon", "", 12456, "Terrible Pro", "Proyecto 1");    

INSERT INTO usuario
	(rutcliente, rutprofecional, usuario, clave, fecha)
VALUES
	(123456789, 987654321, "Netero", "123", "1981-08-08"),
	(234567891, 876543219, "Naruto", "123", "1981-08-08"),
	(345678912, 765432198, "Gon", "123", "1981-08-08");

INSERT INTO administrativos
	(rut, nombre, apellido, correo, area, idusuario)
VALUES
	(1, "nombre 1", "apellido 1", "a@b.cl", "Aqui", 1),
    (2, "nombre 2", "apellido 2", "a@b.cl", "Aqui", 2),
	(3, "nombre 3", "apellido 3", "a@b.cl", "Aqui", 3);

INSERT INTO asesorias
	(fecharealizacion, motivo, rutprofecional)
VALUES
	("2022-08-08", "Motivo 1", 987654321),
    ("2022-08-09", "Motivo 2", 876543219),
    ("2022-08-10", "Motivo 3", 765432198);
    
INSERT INTO actividades
	(titulomejora, descripcion, plazoendias, idasesoria)
VALUES
	("Titulo 1", "Descripcion 1", 3, 1),
    ("Titulo 2", "Descripcion 2", 3, 2),
    ("Titulo 3", "Descripcion 3", 3, 3);

-- 3
SELECT
	a.asisnombrecompleto,
    a.asisedad,
    asiscorreo
FROM asistentes a 
	INNER JOIN capacitacion b ON b.idcapacitacion = a.idcapacitacion
	INNER JOIN cliente c ON c.rutcliente = b.rutcliente
WHERE c.rutcliente = 123456789;

SELECT
	a.nombre,
    b.cumplimiento,
    b.obs,
    c.visfecha,
    c.vishora,
    c.vislugar,
    c.viscomentario,
    d.clicomuna
FROM mae_chequeo a 
	INNER JOIN chequeo_visita b ON b.idchequeo = a.id
    INNER JOIN visita c ON c.idvisita = b.idvisita
    INNER JOIN cliente d ON d.rutcliente = c.rutcliente
WHERE d.clicomuna = "Valparaiso";

SELECT 
	a.accfecha,
    a.accfecha,
    a.acclugar,
    a.accorigen,
    a.accconsecuencias,
    b.rutcliente,
    b.clinombres,
    b.cliapellidos,
    b.clitelefono
FROM accidente a INNER JOIN cliente b ON a.rutcliente = b.rutcliente;

/*
SELECT * FROM cliente;
SELECT * FROM accidente;
SELECT * FROM visita;
SELECT * FROM mae_chequeo;
SELECT * FROM chequeo_visita;
SELECT * FROM pago;
SELECT * FROM capacitacion;
SELECT * FROM asistentes;
SELECT * FROM usuario;
SELECT * FROM administrativos;
SELECT * FROM profesional;
SELECT * FROM asesorias;
SELECT * FROM actividades;
*/
